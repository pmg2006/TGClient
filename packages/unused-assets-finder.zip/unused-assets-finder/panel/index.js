const fs = require('fs');


Editor.Panel.extend({
  style: `
    :host { margin: 5px; }
    h2 { color: #f90; }
  `,

  template: `
    <div><ui-button id="btn-find">Find Unused Assets</ui-button></div>
    <ui-scroll-view id="list" style="width: 100%; height: 300px;"></ui-scroll-view>
  `,

  $: {
    btnFind: '#btn-find',
    list: '#list'
  },

  allUUIDs:any = [],


  ready() {
    this.$btnFind.addEventListener('confirm', () => {
      this.findDependencies();
    });
  },

  getUuids(obj) {
    Editor.log(`Object structure: ${JSON.stringify(obj, null, 2)}`);
   
    if (Array.isArray(obj)) {
      obj.forEach(item => this.getUuids(item));
    } else if (obj && typeof obj === 'object') {
      if (obj._spriteFrame && obj._spriteFrame.__uuid__) {
        if (!this.allUUIDs.includes(obj._spriteFrame.__uuid__)) {
          Editor.log(`Found uuid: ${obj._spriteFrame.__uuid__}`);
          this.allUUIDs.push(obj._spriteFrame.__uuid__);
        }
      }
      Object.values(obj).forEach(value => this.getUuids(value));
    }
  },
  findDependencies() {


    Editor.log('Finding dependencies...1');

    // 获取项目中所有的场景和预制体资源
    var url = 'db://assets/**/*';
    Editor.assetdb.queryAssets(url, ['scene', 'prefab'], (err, assets) => {
      if (err) {
        Editor.error(err);
        return;
      }
     // Editor.log(`Number of assets: ${assets.length}`);

      // Iterate over scene and prefab resources, read data directly from file path
      for (const asset of assets) {
        //Editor.log(`Asset: ${JSON.stringify(asset)}`);
        const path = asset.path;
        fs.readFile(path, 'utf8', (err, data) => {
          if (err) {
            Editor.error(err);
            return;
          }
          // Use regex to directly get __uuid__ and _spriteFrame similar to linux grep, improving efficiency
          const regexSpriteFrame = /"_spriteFrame": {\s* "__uuid__": "([^"]*)"/g;
          const regexSprite = /"spriteFrame": {\s* "__uuid__": "([^"]*)"/g;
          let matchSpriteFrame, matchSprite;
          while ((matchSpriteFrame = regexSpriteFrame.exec(data)) !== null || (matchSprite = regexSprite.exec(data)) !== null) {
            const uuidSpriteFrame = matchSpriteFrame ? matchSpriteFrame[1] : null;
            const uuidSprite = matchSprite ? matchSprite[1] : null;
            const uuids = [uuidSpriteFrame, uuidSprite].filter(Boolean);
            
            uuids.forEach(uuid => {
              //Editor.log(`UUID: ${uuid}`);
              
              if (!this.allUUIDs.includes(uuid)) {
                //Editor.log(`Found uuid: ${uuid}`);
                this.allUUIDs.push(uuid);
              }
              // Print asset information if UUID matches the specified UUID
              if (uuid == 'fc6f25bc-4476-4200-bb7e-1ffeb1a71931') {
               //Editor.log(`Asset with specified UUID: ${JSON.stringify(asset)}`);
              }
            });
          }
        // Check if asset has a valid UUID

        });
      }
      

      //Editor.log("11111111111111111111111111111");
      // 获取指定目录中的图片资源
      Editor.assetdb.queryAssets('db://assets/main/Image/*', ['sprite-frame', 'texture'], (err, images) => {
        if (err) {
          Editor.error(err);
          return;
        }
        //Editor.log(`Number of UUIDs: ${this.allUUIDs.length}`);
       // Editor.log(`Number of images: ${images.length}`);

        // Check if image is in the dependencies of any scene or prefab
        for (const image of images) {
          const metaPath = image.path + ".meta";
          fs.readFile(metaPath, 'utf8', (err, data) => {
            if (err) {
              Editor.error(err);
              return;
            }
            const meta = JSON.parse(data);
            
            const subMetas = meta.subMetas;
            const uuid = Object.values(subMetas).map(subMeta => subMeta.uuid);
            //Editor.log(`Image with specified UUID: ${JSON.stringify(image)}`);

            
            if (!this.allUUIDs.includes(uuid+"")) {
              //Delete unused resources and their meta files
              fs.unlink(image.path, (err) => {
                if (err) throw err;
                // Delete the corresponding .meta file
                fs.unlink(image.path + '.meta', (err) => {
                  if (err) throw err;
                });
              });
            
            } else {
              Editor.log(`被引用的资源: ${image.path}`);
            }
            // Print image information if UUID matches the specified UUID
            if (uuid == '3bc5bfb0-49cd-498b-b160-f1738fc6e658') {
             // Editor.log(`Image with specified UUID: ${JSON.stringify(image)}`);
            }
            // Print information if image is bar.png
            // if (image.url.endsWith('bar.png')) {
            //   Editor.log(`UUID of image bar.png: ${uuid}`);
              
            //   Editor.log(`Information of image bar.png: ${JSON.stringify(image)}`);
            //   Editor.log(`Meta information: ${JSON.stringify(meta)}`);

            // }
          });
        }
      });

      
    });

   
  }
});