'use strict';module.exports={load(){},unload(){},messages:{'open'(){Editor.Panel.open('search_scene_all_resouces')},},};
