"use strict";
module.exports = {
    description: "一个更好用的国际化多语言解决方案",
    open_panel: "super i18n",
};