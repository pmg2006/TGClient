"use strict";
module.exports = {
    description: "A better international multilingual solutions",
    open_panel: "super i18n",
};